
bar();

function bar(){
  console.log("bar");
}

// myFunc(); // erreur

const myFunc = function(){
    console.log("Expression")
}

myFunc();
